[Trauma Call v1.2](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#17080)
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTEzMzc4NTc2OTNdfQ==
-->