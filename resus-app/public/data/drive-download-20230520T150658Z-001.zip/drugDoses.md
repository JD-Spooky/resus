## Emergency Drug doses

![Drug Doses](./guidelines.md/drug_doses.png)

https://www.resus.org.uk/_resources/assets/attachment/full/0/1367.pdf

<!--stackedit_data:
eyJoaXN0b3J5IjpbNjUxNzE1MDMwLC0yMzU2ODQ0NjddfQ==
-->