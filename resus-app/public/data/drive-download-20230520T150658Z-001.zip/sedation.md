


[Sedation v1.1](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#13881)

[Sedation checklist](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#13859)
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTE3MjY1MDg1NjddfQ==
-->