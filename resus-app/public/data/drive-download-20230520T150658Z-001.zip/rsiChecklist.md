# RSI checklist
![RSI checklist](./guidelines.md/rsiChecklist.png)
Link to difficult airway guidelines

--- 
eResus v2.0 based on [Intubation Checklist v5 (COVID)](http://nww.avon.nhs.uk/dms/Download.aspx?r=1&did=24112&f=PaediatricEmergencyIntubationChecklist-5_0.pdf)
<!--stackedit_data:
eyJoaXN0b3J5IjpbNDUyODkwMTEzXX0=
-->