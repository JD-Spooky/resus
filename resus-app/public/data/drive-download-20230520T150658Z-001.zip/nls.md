# Newborn Life Support
![RSI checklist](./guidelines.md/nls.png)

--- 
eResus v2.0 based on [Resus council NLS](https://www.resus.org.uk/resuscitation-guidelines/resuscitation-and-support-of-transition-of-babies-at-birth/)
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTIyMDQ0NTE5NV19
-->