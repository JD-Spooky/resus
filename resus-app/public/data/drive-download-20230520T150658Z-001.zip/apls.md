
![APLS algorithm](./guidelines.md/apls.png)

--- 
eResus v2.0 based on [APLS 6th edition](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#18097)

[https://www.resus.org.uk/resuscitation-guidelines/paediatric-advanced-life-support/](https://www.resus.org.uk/resuscitation-guidelines/paediatric-advanced-life-support/)
ALSG 6e
[https://www.alsg.org/fileadmin/_temp_/Specific/Ch06_CA.pdf](https://www.alsg.org/fileadmin/_temp_/Specific/Ch06_CA.pdf)
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTE0NzU4MTQ0ODBdfQ==
-->