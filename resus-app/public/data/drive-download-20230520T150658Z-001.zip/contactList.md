People
PICU fellow bleep 6733
Outreach bleep 2968
RMO bleep 2943
Specialty 1 bleep 2289
Specialty 2 bleep 6734
Anaesthetist consultant 27888
Anaesthetist SpR 2937 (day)
Cardiology SpR bleep2424
Surgery SpR bleep2723
Neurosurgery SpR bleep 6730
Orthopedics SpR bleep 6744 (OOH 5184)
Plastics SPR RP via switch
ENT SpR bleep 2107 (OOH 2920)
Radiographer bleep 2726
Radiology hub ext 20921 
Site Manager bleep 3217
Theatre coordinator 28583 (bleep 2025)
Porter Day
Equipment bleep 2471
Patient moves bleep 2944
Pathology bleep 3009
Porter night bleep 2955

ED Consultants
Anne Frampton	07725 980445	
Giles Haythornthwaite	07891 164598	0127 5331718
Mark Lyttle	07788185454	
Nick Sargant	07979 857487	
Paul Reavley	07974 195647	0117 9736053
Sam Milsom	07966 364491	
Will Christian	07966 549318	0117 9467827

Labs
Transfusion ext 22579
Haematology bleep 22521/ 22594
Biochemistry bleep 2331
Microbiology bleep 22514/22572

Departments
A&E reception 28344
PICU nurse base 28546/28377/28546
Theatre reception 28595
Theatre 4 28560

--- 
eResus v2.0 based on [Abdominal Trauma vX.X](http://test.com)




<!--stackedit_data:
eyJoaXN0b3J5IjpbLTc4MzAwNzYwMF19
-->