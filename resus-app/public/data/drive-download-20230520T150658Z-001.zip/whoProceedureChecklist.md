# WHO procedure Checklist
![WHO proceedure checklist](./guidelines.md/whoProceedureChecklist.png)

--- 
eResus v2.0
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTUwMTQzNTU0XX0=
-->