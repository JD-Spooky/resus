# Head Injury
![Head injury](./guidelines.md/headInjury.png)

Consider transexamic acid?

--- 
eResus v2.0 based on  [Childhood head injury V3.2](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#8921)
[Severe head injury v4](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#16571)

<!--stackedit_data:
eyJoaXN0b3J5IjpbMTQ1MzAxMTUyN119
-->