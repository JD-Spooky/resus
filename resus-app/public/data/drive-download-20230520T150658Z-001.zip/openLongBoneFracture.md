# Open long bone fracture
![Burns algorithm](./guidelines.md/openLongBoneFracture.png)
Link pain management
link compartment syndrome
link antibiotic guidelines

--- 
eResus v2.0 based on [Open fracture v2.0](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#19458)
<!--stackedit_data:
eyJoaXN0b3J5IjpbMTQyNTM2NDkzNF19
-->