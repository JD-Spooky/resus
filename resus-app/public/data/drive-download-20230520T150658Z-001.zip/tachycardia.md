# Tachycardia
### Supra Ventricular Tachycardia
![RSI checklist](./guidelines.md/tachycardia_svt.png)
![RSI checklist](./guidelines.md/tachycardia_svt_algo.png)

### Ventricular Tachycardia
![RSI checklist](./guidelines.md/tachycardia_vt_algo.png)

### Torsades de Points
![RSI checklist](./guidelines.md/tachycardia_tdp.png)Treatment magnesium sulphate
Dose 25–50 mg/kg (max 2 g) rapid IV infusion over several minutes

--- 
eResus v2.0 based on [SVT V2](http://workspaces/sites/Teams/ChildrensEmergencyDepartment/guidelines/BCH_guidelines/1/index.html#18664)

https://www.alsg.org/en/files/Ch10_Abnormal_rate_or_rhythm2006.pdf
